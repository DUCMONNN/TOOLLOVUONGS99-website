
# Hướng dẫn deploy trang HTML (Static)

Đây là gói đã sẵn sàng deploy, gồm:
- `index.html` (đã lấy từ file bạn gửi)
- `logo.png` (placeholder để tránh lỗi 404 hình logo)
- (Không cần backend)

## Cách 1: GitHub Pages (miễn phí)
1) Tạo repo mới trên GitHub (vd: `ai-taixiu-web`).
2) Upload 2 file: `index.html`, `logo.png` vào repo (drag & drop).
3) Vào **Settings → Pages**:
   - Source: **Deploy from a branch**
   - Branch: `main` (root `/`), rồi **Save**.
4) Sau 1–2 phút, trang sẽ chạy tại URL GitHub Pages của bạn.

## Cách 2: Netlify (miễn phí, nhanh)
1) Vào netlify.com → **Add new site** → **Deploy manually**.
2) Kéo thả cả thư mục (hoặc file ZIP này) vào khung upload.
3) Build settings: **không cần**, vì là static.
4) Netlify sẽ tạo domain ngẫu nhiên, bạn có thể đổi tên site.
   - Nếu muốn tự động redirect về `index.html`, có thể thêm `_redirects` (không bắt buộc).

## Cách 3: Vercel (miễn phí)
1) Vào vercel.com → **Add New… → Project**.
2) **Import** từ GitHub repo chứa `index.html` (hoặc **Deploy** thư mục này bằng Vercel CLI).
3) Framework: **Other** (Static). No build command. Output dir: `/`.
4) Deploy xong sẽ có domain *.vercel.app.

## Gợi ý tối ưu
- File đang load Tailwind qua CDN – giữ nguyên được.
- Ảnh logo: thay `logo.png` bằng ảnh thật của bạn khi có.
- Nếu muốn SEO tốt hơn: bổ sung `<meta name="description" ...>` & favicon.

Chúc bạn deploy mượt!
